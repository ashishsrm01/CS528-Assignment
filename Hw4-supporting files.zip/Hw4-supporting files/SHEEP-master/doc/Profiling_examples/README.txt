The profiling was carried out for 5 libraries: HElib-f2, HElib-fp, LP, SEAL and TFHE using 
bool type and a circuit containing 7 (6) gates. The test circuits for each library can be 
found in the /backend/tests/ directory with a suffix c7.

> HElib-f2, HElib, SEAL, TFHE (Executed x100 for statistics)

4 - Add and 3 Multiply gates

> HElib-fp (Executed x100 for statistics)

4 - Add and 2 Multiply gates

If 3 Multiply gates are used, the results are random!

> LP (Executed x1000 for statistics)

7 Add gates