#ifndef CONTEXT_TFHE_HPP
#define CONTEXT_TFHE_HPP

#include "context-tfhe-bool.hpp"
#include "context-tfhe-integer.hpp"

#endif  // CONTEXT_TFHE_HPP
